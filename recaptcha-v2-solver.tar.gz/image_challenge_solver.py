"""reCAPTCHA v2 image challenge solver using Mistral vision API"""
import base64
import io
import json
import aiohttp
from typing import List, Optional, Tuple
from logmagix import Logger


MISTRAL_API_URL = "https://api.mistral.ai/v1/chat/completions"
MISTRAL_MODEL = "mistral-medium-latest"


class ImageChallengeSolver:
    """Solves reCAPTCHA v2 image grid challenges using Mistral vision API"""
    
    def __init__(self, api_key: str, debug: bool = False):
        self.api_key = api_key
        self.debug = debug
        self.log = Logger()
    
    async def solve_grid(self, page, challenge_iframe) -> bool:
        """
        Solve an image grid challenge.
        Returns True if successfully solved, False if failed.
        """
        # 1. Get the challenge instruction text
        instruction = await self._get_instruction(challenge_iframe)
        if not instruction:
            self.log.failure("Could not read challenge instruction")
            return False
        
        if self.debug:
            self.log.debug(f"Challenge instruction: {instruction}")
        
        # 2. Take screenshot of the challenge area
        screenshot = await self._take_challenge_screenshot(page)
        if not screenshot:
            self.log.failure("Could not screenshot challenge")
            return False
        
        # 3. Send to vision model for analysis
        clicks = await self._analyze_with_vision(screenshot, instruction)
        if not clicks:
            self.log.failure("Vision model could not analyze the grid")
            return False
        
        if self.debug:
            self.log.debug(f"Vision model suggests clicking: {clicks}")
        
        # 4. Click the suggested cells
        for row, col in clicks:
            await self._click_cell(challenge_iframe, row, col)
            await asyncio.sleep(0.3)  # Small delay between clicks
        
        # 5. Click verify/submit button
        await asyncio.sleep(1)
        try:
            verify_btn = await challenge_iframe.wait_for_selector(
                "#recaptcha-verify-button", state="visible", timeout=3000
            )
            await verify_btn.click()
        except:
            pass
        
        return True
    
    async def _get_instruction(self, challenge_iframe) -> Optional[str]:
        """Extract the challenge instruction text"""
        try:
            # Try multiple selectors for the instruction
            selectors = [
                ".rc-imageselect-instructions .rc-imageselect-desc-wrapper",
                ".rc-imageselect-instructions",
                ".rc-imageselect-desc",
            ]
            for sel in selectors:
                try:
                    el = await challenge_iframe.wait_for_selector(sel, state="visible", timeout=2000)
                    if el:
                        text = await el.text_content()
                        if text and len(text.strip()) > 3:
                            return text.strip()
                except:
                    continue
        except:
            pass
        return None
    
    async def _take_challenge_screenshot(self, page) -> Optional[bytes]:
        """Screenshot the reCAPTCHA challenge area"""
        try:
            # Find the challenge iframe and screenshot it
            iframe_el = await page.wait_for_selector(
                "iframe[src*='google.com/recaptcha/api2/bframe'], iframe[src*='google.com/recaptcha/enterprise/bframe']",
                timeout=3000
            )
            if iframe_el:
                return await iframe_el.screenshot(type="png")
        except:
            pass
        # Fallback: full page screenshot
        try:
            return await page.screenshot(type="png")
        except:
            return None
    
    async def _analyze_with_vision(self, screenshot_bytes: bytes, instruction: str) -> List[Tuple[int, int]]:
        """Send screenshot to Mistral vision API and get click coordinates"""
        b64 = base64.b64encode(screenshot_bytes).decode()
        
        prompt = f"""You are a reCAPTCHA solver. The challenge instruction is: "{instruction}"

This is a screenshot of a reCAPTCHA image grid challenge. The grid is typically 3x3 (rows 0-2, columns 0-2) or 4x4.

Analyze each cell in the grid. For each cell that matches the instruction, note its row and column position (0-indexed).

Return ONLY a JSON array of [row, column] pairs for cells that should be clicked. Example: [[0,0],[1,2],[2,1]]

If no cells match, return []."""

        payload = {
            "model": MISTRAL_MODEL,
            "messages": [{
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}}
                ]
            }],
            "max_tokens": 200,
            "temperature": 0.1
        }
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(MISTRAL_API_URL, json=payload, headers=headers, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                    if resp.status != 200:
                        text = await resp.text()
                        self.log.failure(f"Vision API error {resp.status}: {text[:200]}")
                        return []
                    result = await resp.json()
                    content = result["choices"][0]["message"]["content"].strip()
                    
                    if self.debug:
                        self.log.debug(f"Vision model raw response: {content}")
                    
                    # Parse JSON from response
                    # Try to extract JSON array from the response
                    import re
                    json_match = re.search(r'\[.*\]', content, re.DOTALL)
                    if json_match:
                        clicks = json.loads(json_match.group())
                        return [tuple(c) for c in clicks]
                    return []
        except Exception as e:
            self.log.failure(f"Vision API request failed: {e}")
            return []
    
    async def _click_cell(self, challenge_iframe, row: int, col: int):
        """Click a specific cell in the grid"""
        try:
            # reCAPTCHA uses table cells with specific class patterns
            # Each cell is a td in the image table
            cells = await challenge_iframe.query_selector_all(".rc-imageselect-tile")
            if not cells:
                cells = await challenge_iframe.query_selector_all("td.rc-imageselect-tile")
            
            # Determine grid size (usually 9 for 3x3 or 16 for 4x4)
            grid_size = len(cells)
            if grid_size == 0:
                return
            
            cols = 3 if grid_size == 9 else 4 if grid_size == 16 else 3
            idx = row * cols + col
            
            if 0 <= idx < grid_size:
                await cells[idx].click()
                if self.debug:
                    self.log.debug(f"Clicked cell [{row},{col}] (index {idx})")
        except Exception as e:
            if self.debug:
                self.log.debug(f"Click failed [{row},{col}]: {e}")


import asyncio  # needed at module level for _click_cell