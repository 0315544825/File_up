"""reCAPTCHA v2 Solver using CloakBrowser (anti-detect) instead of Patchright"""
import io
import time
import asyncio
from typing import Optional, Dict
import aiohttp
import speech_recognition as sr
from pydub import AudioSegment
from logmagix import Logger, Loader
from cloakbrowser import launch_async
from image_challenge_solver import ImageChallengeSolver


class AudioProcessor:
    def __init__(self, debug: bool = False):
        self.recognizer = sr.Recognizer()
        self.debug = debug
        self.log = Logger()
        self._session = None

    async def __aenter__(self):
        self._session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._session:
            await self._session.close()

    async def process_audio(self, audio_url: str) -> str:
        audio_content = await self._download_audio(audio_url)
        audio_bytes = await self._convert_to_wav(audio_content)
        return await self._convert_audio_to_text(audio_bytes)

    async def _download_audio(self, audio_url: str) -> bytes:
        if not self._session:
            self._session = aiohttp.ClientSession()
        async with self._session.get(audio_url) as response:
            if response.status != 200:
                raise Exception(f"Failed to download audio. Status: {response.status}")
            return await response.read()

    async def _convert_to_wav(self, audio_content: bytes) -> io.BytesIO:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._convert_to_wav_sync, audio_content)

    def _convert_to_wav_sync(self, audio_content: bytes) -> io.BytesIO:
        audio_bytes = io.BytesIO(audio_content)
        audio = AudioSegment.from_mp3(audio_bytes)
        audio = audio.set_frame_rate(16000).set_channels(1)
        wav_bytes = io.BytesIO()
        audio.export(wav_bytes, format="wav", parameters=["-q:a", "0"])
        wav_bytes.seek(0)
        return wav_bytes

    async def _convert_audio_to_text(self, wav_bytes: io.BytesIO) -> str:
        loop = asyncio.get_event_loop()
        try:
            return await loop.run_in_executor(None, self._convert_audio_to_text_sync, wav_bytes)
        except Exception as e:
            try: Loader.stop()
            except: pass
            raise e

    def _convert_audio_to_text_sync(self, wav_bytes: io.BytesIO) -> str:
        with sr.AudioFile(wav_bytes) as source:
            audio = self.recognizer.record(source)
            try:
                text = str(self.recognizer.recognize_google(audio))
                if self.debug:
                    self.log.debug(f"Raw recognized text: {text}")
                cleaned_text = ''.join(c.lower() for c in text if c.isalnum() or c.isspace())
                if not cleaned_text:
                    raise sr.UnknownValueError("Empty audio response")
                return cleaned_text.strip()
            except sr.UnknownValueError:
                raise Exception("Could not understand audio")
            except sr.RequestError:
                raise Exception("Speech recognition service error")
            except Exception as e:
                raise Exception(f"Audio conversion error: {str(e)}")


class ReCaptchaCloakSolver:
    HTML_TEMPLATE = """
    <!DOCTYPE html>
    <html>
        <head>
            <script src="https://www.google.com/recaptcha/api.js" async defer></script>
        </head>
        <body>
            <div class="g-recaptcha" data-sitekey="{sitekey}"></div>
        </body>
    </html>
    """

    def __init__(self, page, debug: bool = False, mistral_api_key: Optional[str] = None):
        self.page = page
        self.debug = debug
        self.log = Logger()
        self.page.set_default_timeout(20000)
        self.audio_processor = AudioProcessor(debug)
        self.image_solver = ImageChallengeSolver(mistral_api_key, debug) if mistral_api_key else None

    @classmethod
    async def solve_recaptcha(cls, url: str, proxy: Optional[Dict] = None, debug: bool = False,
                               site_key: Optional[str] = None, wait: int = None,
                               mistral_api_key: Optional[str] = None) -> str:
        loader = Loader(desc="Solving reCAPTCHA...", timeout=0.05)
        loader.start()
        start_time = time.time()

        browser = await launch_async(headless=False, humanize=True)
        try:
            context = await browser.new_context(
                locale="en-US",
                java_script_enabled=True,
                bypass_csp=True,
                viewport={"width": 1280, "height": 800},
                device_scale_factor=1,
                is_mobile=False,
                ignore_https_errors=True,
            )
            page = await context.new_page()
            await page.goto(url, wait_until="domcontentloaded")

            solver = cls(page, debug, mistral_api_key)
            token = await solver._solve()
            end_time = time.time()
            loader.stop()

            Logger().message(
                "reCAPTCHA",
                f"Solved in {end_time - start_time:.1f}s",
                start=start_time, end=end_time
            )
            return token
        except Exception as e:
            loader.stop()
            if "rate limit" in str(e).lower():
                raise Exception("Rate limit reached, consider using or changing your proxy.")
            raise e
        finally:
            if wait:
                await asyncio.sleep(wait)
            try: await context.close()
            except: pass
            try: await browser.close()
            except: pass

    async def _solve(self) -> str:
        try:
            iframe = await self._handle_initial_iframe()
            challenge_iframe = await self._handle_challenge_iframe()
            if not challenge_iframe:
                return await self._get_token()
            
            # Check if this is an image challenge or audio challenge
            # Try image challenge first if vision API is available
            is_image_challenge = await self._detect_image_challenge(challenge_iframe)
            
            if is_image_challenge and self.image_solver:
                if self.debug:
                    self.log.debug("Detected image challenge, using vision API")
                # Try image challenge with vision model (up to 3 rounds)
                for round_num in range(3):
                    success = await self.image_solver.solve_grid(self.page, challenge_iframe)
                    if not success:
                        break
                    # Wait for potential new round or token
                    await asyncio.sleep(2)
                    # Check if we got a token
                    try:
                        token = await self._get_token()
                        return token
                    except:
                        pass
                    # Check if there's a new round of images
                    try:
                        new_challenge = await self._handle_challenge_iframe()
                        if new_challenge:
                            challenge_iframe = new_challenge
                            continue
                    except:
                        pass
                    break
                # If image challenge failed, fall through to audio
            
            # Try audio challenge
            try:
                audio_url = await self._get_audio_challenge(challenge_iframe)
                async with self.audio_processor as processor:
                    audio_text = await processor.process_audio(audio_url)
                await self._submit_audio_solution(challenge_iframe, audio_text)
                return await self._get_token()
            except Exception as audio_err:
                if "rate limit" in str(audio_err).lower():
                    raise
                # Audio failed, if we have vision try image as fallback
                if self.image_solver and not is_image_challenge:
                    if self.debug:
                        self.log.debug("Audio failed, trying image challenge with vision API")
                    success = await self.image_solver.solve_grid(self.page, challenge_iframe)
                    if success:
                        await asyncio.sleep(2)
                raise Exception(f"Failed to solve reCAPTCHA: {str(audio_err)}")
        except Exception as e:
            try: Loader.stop()
            except: pass
            raise Exception(f"Failed to solve reCAPTCHA: {str(e)}")

    async def _detect_image_challenge(self, challenge_iframe) -> bool:
        """Detect if the challenge is showing image grid (vs audio)"""
        try:
            # If we see image grid tiles, it's an image challenge
            tiles = await challenge_iframe.query_selector_all(".rc-imageselect-tile")
            if tiles and len(tiles) > 0:
                return True
        except:
            pass
        return False

    async def _handle_initial_iframe(self):
        iframe = await self.page.wait_for_selector(
            "iframe[src*='google.com/recaptcha/api2/anchor'], iframe[src*='google.com/recaptcha/enterprise/anchor']",
            strict=True
        )
        iframe = await iframe.content_frame()
        checkbox = await iframe.wait_for_selector("#recaptcha-anchor", state="visible", strict=True)
        await checkbox.click()
        return iframe

    async def _handle_challenge_iframe(self):
        try:
            challenge_iframe = await self.page.wait_for_selector(
                "iframe[src*='google.com/recaptcha/api2/bframe'], iframe[src*='google.com/recaptcha/enterprise/bframe']",
                timeout=3000, strict=True
            )
            return await challenge_iframe.content_frame()
        except:
            return None

    async def _get_audio_challenge(self, challenge_iframe) -> str:
        try:
            audio_button = await challenge_iframe.wait_for_selector(
                "#recaptcha-audio-button", state="visible", timeout=2000, strict=True
            )
            await audio_button.click()
        except:
            if await self._check_rate_limit(challenge_iframe):
                raise Exception("Rate limit reached, consider using or changing your proxy.")
            raise
        try:
            download_button = await challenge_iframe.wait_for_selector(
                ".rc-audiochallenge-tdownload-link", state="visible", timeout=5000
            )
            audio_url = await download_button.get_attribute("href")
            if not audio_url:
                raise Exception("Could not get audio URL")
            return audio_url
        except:
            if await self._check_rate_limit(challenge_iframe):
                raise Exception("Rate limit reached, consider using or changing your proxy.")
            raise

    async def _submit_audio_solution(self, challenge_iframe, audio_text: str):
        response_input = await challenge_iframe.wait_for_selector("#audio-response", state="visible")
        await response_input.fill(audio_text)
        verify_button = await challenge_iframe.wait_for_selector("#recaptcha-verify-button", state="visible")
        await verify_button.click()

    async def _check_rate_limit(self, frame) -> bool:
        try:
            rate_limit_element = frame.locator(".rc-doscaptcha-header")
            text = await rate_limit_element.text_content()
            return "Try again later" in text
        except:
            return False

    async def _get_token(self) -> str:
        for method in [self._get_response_token, self._get_bframe_token, self._get_frame_token, self._get_enterprise_token]:
            try:
                token = await method()
                if token:
                    return str(token)
            except: pass
        raise Exception("Could not retrieve reCAPTCHA token")

    async def _get_response_token(self):
        return await self.page.evaluate('(() => { const r = document.getElementById("g-recaptcha-response"); return r ? r.value : null; })()')

    async def _get_bframe_token(self):
        return await self.page.evaluate('(() => { for (const f of window.frames) { try { const t = f.document.getElementById("recaptcha-token"); if (t) return t.value; } catch(e) {} } return null; })()')

    async def _get_frame_token(self):
        for frame in self.page.frames:
            try:
                token = await frame.evaluate('document.getElementById("recaptcha-token").value')
                if token: return token
            except: continue
        return None

    async def _get_enterprise_token(self):
        return await self.page.evaluate('(() => { const r = document.querySelector("[name=recaptcha-token]"); return r ? r.value : null; })()')