# reCAPTCHA v2 Solver

Solve Google reCAPTCHA v2 challenges using CloakBrowser (anti-detect) + Mistral Vision API.

## Features

- **Dual-mode solving**: Image challenge (Mistral vision) + Audio challenge (speech recognition)
- **CloakBrowser**: Anti-detection Chromium, passes bot detection
- **Anti-captcha compatible API**: `createTask` / `getTaskResult` pattern
- **Xvfb support**: Headless server-ready with virtual display

## Requirements

- Python 3.11+
- Xvfb (display :99)
- CloakBrowser (bundled via pip)
- Mistral API key (for image challenge mode)
- ffmpeg (for audio processing)

## Quick Start

```bash
# 1. Create venv & install dependencies
python3 -m venv venv
. venv/bin/activate
pip install -r requirements.txt
pip install httpx pystyle cloakbrowser

# 2. Install Patchright's Chromium (CloakBrowser dependency)
patchright install chromium

# 3. Start Xvfb (if running headless)
Xvfb :99 -screen 0 1280x720x24 &
export DISPLAY=:99

# 4. Set Mistral API key
export MISTRAL_API_KEY="your-key-here"

# 5. Start the API server
python recaptcha_api_v2.py
```

Server runs on **port 5002**.

## API Endpoints

### Health Check
```
GET /health
→ {"status": "healthy", "service": "recaptcha-v2-solver", "browser": "cloakbrowser", "vision": "mistral-medium-latest"}
```

### Create Task (Anti-captcha compatible)
```
POST /createTask
Content-Type: application/json

{
  "task": {
    "type": "ReCaptchaV2TaskProxyless",
    "websiteURL": "https://example.com/page-with-recaptcha",
    "websiteKey": "6Le-xxxx..."
  }
}

→ {"errorId": 0, "taskId": "uuid"}
```

### Get Task Result
```
GET /getTaskResult?id=<taskId>

Processing:
→ {"errorId": 0, "status": "processing"}

Ready:
→ {"errorId": 0, "status": "ready", "solution": {"gRecaptchaResponse": "03AFcWeA..."}}

Failed:
→ {"errorId": 1, "status": "failed", "errorDescription": "..."}
```

### Direct Solve
```
POST /solve
Content-Type: application/json

{
  "url": "https://example.com/page",
  "sitekey": "6Le-xxxx..."
}

→ {"success": true, "token": "03AFcWeA..."}
```

## How It Works

### Image Challenge (Priority)
1. CloakBrowser opens target page → clicks "I'm not a robot"
2. If image grid challenge appears → screenshot the challenge
3. Send screenshot + instruction text to **Mistral vision API** (`mistral-medium-latest`)
4. Vision model returns which grid cells to click `[row, col]`
5. Click matching cells → submit → repeat if new round → get token

### Audio Challenge (Fallback)
1. Switch to audio mode → download audio MP3
2. Convert to WAV → Google Speech Recognition API transcribes
3. Submit transcribed text → get token

### Fallback Chain
```
Image challenge (Mistral vision) → if fails → Audio challenge (speech recognition)
Audio rate limited → try Image challenge if not already tried
```

## Configuration

| Env Var | Default | Description |
|---|---|---|
| `MISTRAL_API_KEY` | (required) | Mistral API key for vision model |
| `DISPLAY` | `:99` | Xvfb display for CloakBrowser |
| Port | `5002` | API server port (hardcoded in `recaptcha_api_v2.py`) |

## File Structure

```
RecaptchaV2-Solver/
├── recaptcha_api_v2.py       # Main API server (port 5002)
├── recaptcha_cloak_solver.py # Core solver (CloakBrowser + dual mode)
├── image_challenge_solver.py # Mistral vision image grid solver
├── async_solver.py           # Original Patchright solver (reference)
├── api_solver.py             # Original Patchright API (reference)
├── requirements.txt          # Python dependencies
└── README.md                 # This file
```

## Tested Sites

- `https://2captcha.com/demo/recaptcha-v2` — sitekey `6Le-wvkSAAAAAPBMRTvw0Q4Muexq9bi0DJwx_mJ-`

## Notes

- CloakBrowser must run in **headed mode** (`headless=False`) with Xvfb
- Google may rate-limit audio challenges after repeated use
- Mistral vision API costs ~$0.001 per solve
- Token validity is typically 2 minutes after generation