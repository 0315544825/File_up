# reCAPTCHA v2 Solver Skill

Solve Google reCAPTCHA v2 challenges (checkbox, image grid, audio) via a local API endpoint.

## When to Use

- A website presents a Google reCAPTCHA v2 challenge that needs to be solved programmatically
- You need a reCAPTCHA token to submit a form or access a page
- The user asks to bypass or solve a reCAPTCHA

## Prerequisites

The reCAPTCHA v2 solver API must be running locally on port 5002. Start it if not running:

```bash
cd RecaptchaV2-Solver && . venv/bin/activate
export DISPLAY=:99
python recaptcha_api_v2.py
```

Requires Xvfb on display :99 and CloakBrowser installed in the venv.

## Usage

### Step 1: Create a solve task

```
POST http://localhost:5002/createTask
Content-Type: application/json

{
  "task": {
    "type": "ReCaptchaV2TaskProxyless",
    "websiteURL": "https://target-site.com/page",
    "websiteKey": "6Le-xxxx..."
  }
}
```

Response: `{"errorId": 0, "taskId": "uuid"}`

### Step 2: Poll for result

```
GET http://localhost:5002/getTaskResult?id=<taskId>
```

- `"status": "processing"` — still solving, poll again in 5 seconds
- `"status": "ready"` — solved, token in `solution.gRecaptchaResponse`
- `"status": "failed"` — check `errorDescription`

Typical solve time: 8–20 seconds.

### Step 3: Use the token

Inject the `gRecaptchaResponse` token into the page's form field or API request before it expires (~2 minutes).

## How It Solves

| Challenge Type | Method | Fallback |
|---|---|---|
| Image grid | Mistral vision API analyzes cells | Falls back to audio |
| Audio | Download audio → Google Speech Recognition → submit text | Falls back to image (if vision available) |
| Checkbox only | Direct click-through | N/A |

## Finding the Sitekey

The reCAPTCHA sitekey is in the page HTML:
```
<div class="g-recaptcha" data-sitekey="6Le-xxxx...">
```
Or in the iframe src:
```
iframe src="...&k=6Le-xxxx..."
```

Use browser inspection or `page.evaluate()` to extract it.

## Limitations

- reCAPTCHA v3 (invisible/score-based) is NOT supported — use this only for v2
- Audio challenges may be rate-limited by Google after repeated use
- Tokens expire in ~2 minutes — use immediately
- Mistral vision API costs ~$0.001/solve for image challenges

## API Health Check

```
GET http://localhost:5002/health
```

Returns service status and configuration.