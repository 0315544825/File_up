"""reCAPTCHA v2 Solver API — CloakBrowser edition
Port 5002, anti-captcha compatible createTask/getTaskResult pattern
Supports both audio and image (Mistral vision) challenge solving
"""
import asyncio
import time
import uuid
from quart import Quart, request, jsonify
from recaptcha_cloak_solver import ReCaptchaCloakSolver
from logmagix import Logger

MISTRAL_API_KEY = "8Uzefl8UnZ7di4nCPGVR5hssmI0K0yLj"

app = Quart(__name__)
logger = Logger()

tasks = {}


@app.route('/health', methods=['GET'])
async def health_check():
    return jsonify({
        "status": "healthy",
        "service": "recaptcha-v2-solver",
        "browser": "cloakbrowser",
        "vision": "mistral-medium-latest"
    })


@app.route('/createTask', methods=['POST'])
async def create_task():
    try:
        data = await request.get_json()
        if not data or 'task' not in data:
            return jsonify({"errorId": 1, "errorDescription": "Missing task"}), 400

        task = data['task']
        url = task.get('websiteURL')
        site_key = task.get('websiteKey')

        if not url:
            return jsonify({"errorId": 1, "errorDescription": "Missing websiteURL"}), 400

        task_id = str(uuid.uuid4())
        tasks[task_id] = {"status": "processing", "created": time.time()}

        proxy = None
        if task.get('proxy'):
            p = task['proxy']
            proxy = {'server': p.get('server', ''), 'username': p.get('username'), 'password': p.get('password')}

        app.add_background_task(solve_task, task_id, url, site_key, proxy)
        return jsonify({"errorId": 0, "taskId": task_id})

    except Exception as e:
        return jsonify({"errorId": 1, "errorDescription": str(e)}), 500


@app.route('/getTaskResult', methods=['GET'])
async def get_task_result():
    task_id = request.args.get('id') or request.args.get('taskId')
    if not task_id or task_id not in tasks:
        return jsonify({"errorId": 1, "errorDescription": "Task not found"}), 404

    t = tasks[task_id]
    if t['status'] == 'processing':
        return jsonify({"errorId": 0, "status": "processing"})
    elif t['status'] == 'ready':
        return jsonify({"errorId": 0, "status": "ready", "solution": {"gRecaptchaResponse": t['token']}})
    elif t['status'] == 'failed':
        return jsonify({"errorId": 1, "status": "failed", "errorDescription": t.get('error', 'Unknown')})


@app.route('/solve', methods=['POST'])
async def solve_direct():
    try:
        data = await request.get_json()
        if not data or 'url' not in data:
            return jsonify({"success": False, "error": "Missing url"}), 400

        url = data['url']
        site_key = data.get('sitekey') or data.get('websiteKey')
        proxy = data.get('proxy')

        token = await ReCaptchaCloakSolver.solve_recaptcha(
            url=url, site_key=site_key, proxy=proxy, debug=True,
            mistral_api_key=MISTRAL_API_KEY
        )
        return jsonify({"success": True, "token": token})

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


async def solve_task(task_id: str, url: str, site_key: str, proxy: dict):
    try:
        token = await ReCaptchaCloakSolver.solve_recaptcha(
            url=url, site_key=site_key, proxy=proxy, debug=True,
            mistral_api_key=MISTRAL_API_KEY
        )
        tasks[task_id] = {"status": "ready", "token": token}
    except Exception as e:
        tasks[task_id] = {"status": "failed", "error": str(e)}


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002, debug=False)