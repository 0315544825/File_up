# Turnstile Solver 一键部署包

上传到服务器后，只需一条命令：

## 方式一：一键安装（推荐）

```bash
cd turnstile-deploy
bash install.sh
```

安装完成后启动：
```bash
sudo systemctl start turnstile-solver
```

## 方式二：手动启动（无 systemd）

```bash
cd turnstile-deploy
bash install.sh    # 先安装依赖
bash start.sh      # 启动服务
```

## 方式三：Docker

```bash
cd turnstile-deploy
docker build -t turnstile-solver .
docker run -d --name solver -p 5000:5000 --shm-size=2g turnstile-solver
```

## 测试

```bash
curl -X POST http://localhost:5000/turnstile \
  -H 'Content-Type: application/json' \
  -d '{"url": "https://mulerun.com", "sitekey": "0x4AAAAAABnlT9BAdgkYH1Yp"}'

# 用返回的 task_id 查询结果
curl http://localhost:5000/result?id=<task_id>
```

## 文件说明

| 文件 | 说明 |
|------|------|
| `install.sh` | 一键安装脚本（系统依赖 + Python + 浏览器 + systemd） |
| `start.sh` | 手动启动脚本（Xvfb + solver） |
| `api_solver.py` | 核心 API 服务 |
| `index.html` | API 文档首页 |
| `requirements.txt` | Python 依赖 |
| `Dockerfile` | Docker 打包配置 |