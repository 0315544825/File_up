#!/bin/bash
# ── 手动启动脚本（无 systemd 时使用）──────────────────────────────
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# 杀旧进程
pkill -9 Xvfb 2>/dev/null || true
pkill -9 chrome 2>/dev/null || true
pkill -9 api_solver 2>/dev/null || true
sleep 1
rm -f /tmp/.X99-lock

# 启动 Xvfb
Xvfb :99 -screen 0 1920x1080x24 -ac +extension GLX +render -noreset -pn &
XVFB_PID=$!
sleep 2

if ! kill -0 $XVFB_PID 2>/dev/null; then
    echo "ERROR: Xvfb failed to start!"
    exit 1
fi
echo "Xvfb started (PID=$XVFB_PID)"

# 验证 X11
export DISPLAY=:99
xdpyinfo -display :99 >/dev/null 2>&1 || echo "WARNING: X11 display :99 not responding"

# 激活 venv
source "$SCRIPT_DIR/venv/bin/activate"

# 设置环境变量
export DISPLAY=:99
export MOZ_DISABLE_CONTENT_SANDBOX=1
export CLOAKBROWSER_SUPPRESS_FONT_WARNING=1

# 启动 solver
exec python3 "$SCRIPT_DIR/api_solver.py" \
    --thread 1 \
    --host 0.0.0.0 \
    --port 5000 \
    --cors all \
    --debug True