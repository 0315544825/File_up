#!/bin/bash
set -e

# ═══════════════════════════════════════════════════════════════════
#  Turnstile Solver 一键部署脚本
#  用法: bash install.sh
#  支持系统: Ubuntu 20.04+, Debian 11+, CentOS 8+, Amazon Linux 2023
# ═══════════════════════════════════════════════════════════════════

BOLD='\033[1m'
GREEN='\033[32m'
YELLOW='\033[33m'
RED='\033[31m'
RESET='\033[0m'

info()  { echo -e "${GREEN}[✓]${RESET} $1"; }
warn()  { echo -e "${YELLOW}[!]${RESET} $1"; }
error() { echo -e "${RED}[✗]${RESET} $1"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# ── 1. 检测系统 ───────────────────────────────────────────────────
info "检测系统环境..."
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_ID="${ID}"
    OS_VERSION="${VERSION_ID}"
else
    error "无法检测操作系统"
fi
info "系统: ${OS_ID} ${OS_VERSION}"

# ── 2. 安装系统依赖 ──────────────────────────────────────────────
info "安装系统依赖..."
if [ "$OS_ID" = "ubuntu" ] || [ "$OS_ID" = "debian" ]; then
    sudo apt-get update -qq
    sudo apt-get install -y -qq \
        python3 python3-pip python3-venv \
        xvfb fonts-noto-cjk fonts-noto-color-emoji \
        xauth dbus curl wget \
        > /dev/null 2>&1
elif [ "$OS_ID" = "centos" ] || [ "$OS_ID" = "rhel" ] || [ "$OS_ID" = "amzn" ]; then
    sudo yum install -y -q \
        python3 python3-pip \
        xorg-x11-server-Xvfb google-noto-sans-cjk-fonts \
        dbus curl wget \
        > /dev/null 2>&1
else
    warn "未知系统 ${OS_ID}，尝试 Ubuntu 方式安装..."
    sudo apt-get update -qq 2>/dev/null || true
    sudo apt-get install -y -qq python3 python3-pip python3-venv xvfb fonts-noto-cjk 2>/dev/null || true
fi
info "系统依赖安装完成"

# ── 3. 创建 Python 虚拟环境 ───────────────────────────────────────
info "创建 Python 虚拟环境..."
python3 -m venv venv 2>/dev/null || python3 -m venv venv
source venv/bin/activate
info "虚拟环境已激活: $(which python3)"

# ── 4. 安装 Python 依赖 ──────────────────────────────────────────
info "安装 Python 依赖..."
pip install --upgrade pip -q
pip install -r requirements.txt -q
info "Python 依赖安装完成"

# ── 5. 下载浏览器 ─────────────────────────────────────────────────
info "下载 CloakBrowser Chromium (首次可能需要1-2分钟)..."
python3 -c "from cloakbrowser.download import ensure_binary; ensure_binary()" 2>/dev/null
info "CloakBrowser 下载完成"

info "下载 Playwright Chromium (备用浏览器)..."
python3 -m playwright install chromium 2>/dev/null || warn "Playwright Chromium 安装失败 (不影响 CloakBrowser)"
info "浏览器下载完成"

# ── 6. 创建 systemd 服务 ──────────────────────────────────────────
info "配置 systemd 服务..."
SOLVER_PATH="$(cd .. && pwd)/turnstile-solver"
SERVICE_FILE="/etc/systemd/system/turnstile-solver.service"

sudo tee "$SERVICE_FILE" > /dev/null << EOF
[Unit]
Description=Turnstile Solver API
After=network.target

[Service]
Type=simple
User=$(whoami)
WorkingDirectory=$SCRIPT_DIR
Environment=DISPLAY=:99
Environment=MOZ_DISABLE_CONTENT_SANDBOX=1
Environment=CLOAKBROWSER_SUPPRESS_FONT_WARNING=1
Environment=PATH=$SCRIPT_DIR/venv/bin:/usr/local/bin:/usr/bin:/bin
ExecStartPre=/bin/bash -c 'Xvfb :99 -screen 0 1920x1080x24 -ac +extension GLX +render -noreset -pn &'
ExecStartPre=/bin/sleep 2
ExecStart=$SCRIPT_DIR/venv/bin/python3 $SCRIPT_DIR/api_solver.py --thread 1 --host 0.0.0.0 --port 5000 --cors all --debug True
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable turnstile-solver 2>/dev/null || true
info "systemd 服务已配置"

# ── 7. 完成 ───────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}═══════════════════════════════════════════════════${RESET}"
echo -e "${BOLD}${GREEN}  Turnstile Solver 部署完成！${RESET}"
echo -e "${BOLD}═══════════════════════════════════════════════════${RESET}"
echo ""
echo -e "  启动服务:  ${GREEN}sudo systemctl start turnstile-solver${RESET}"
echo -e "  查看状态:  ${GREEN}sudo systemctl status turnstile-solver${RESET}"
echo -e "  查看日志:  ${GREEN}sudo journalctl -u turnstile-solver -f${RESET}"
echo -e "  停止服务:  ${GREEN}sudo systemctl stop turnstile-solver${RESET}"
echo -e "  重启服务:  ${GREEN}sudo systemctl restart turnstile-solver${RESET}"
echo ""
echo -e "  API 地址:  ${GREEN}http://<服务器IP>:5000${RESET}"
echo -e "  测试命令:  ${GREEN}curl -X POST http://localhost:5000/turnstile -H 'Content-Type: application/json' -d '{\"url\": \"https://mulerun.com\", \"sitekey\": \"0x4AAAAAABnlT9BAdgkYH1Yp\"}'${RESET}"
echo ""
echo -e "  ${YELLOW}如果没有 systemd，手动启动:${RESET}"
echo -e "  ${YELLOW}  cd $SCRIPT_DIR && source venv/bin/activate && bash start.sh${RESET}"
echo ""