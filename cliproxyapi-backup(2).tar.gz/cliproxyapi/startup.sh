# CPA stack: cli-proxy-api(:8081) + zen-bridge(:9912) + files(:9913) + caddy(:8080)
pgrep -f 'cli-proxy-api -config' >/dev/null || setsid -f /app/cliproxyapi/cli-proxy-api -config /app/cliproxyapi/config.yaml >> /var/log/cliproxyapi.log 2>&1
pgrep -f zen-bridge.mjs >/dev/null || ZEN_KEY="sk-giy6IGkFIYymmxoxm0kk6vUblVBfslbjrEIqBt2vsUhjNdJwrZJSEHCvVQhWhmAd" setsid -f node /app/cliproxyapi/zen-bridge.mjs >> /var/log/zenbridge.log 2>&1
pgrep -f 'filebrowser.*9913' >/dev/null || (cd /app/filebrowser && setsid -f ./filebrowser -r / -a 127.0.0.1 -p 9913 -b /files -d /app/filebrowser/filebrowser.db >> /var/log/filebrowser.log 2>&1)
pgrep -f 'caddy run --config /app/cliproxyapi/Caddyfile' >/dev/null || setsid -f caddy run --config /app/cliproxyapi/Caddyfile --adapter caddyfile >> /var/log/caddy.log 2>&1
pgrep -f keepalive.sh >/dev/null || setsid -f /app/cliproxyapi/keepalive.sh
