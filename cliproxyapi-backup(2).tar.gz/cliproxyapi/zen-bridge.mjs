// Local bridge: OpenAI chat/completions -> Zen /v1/responses (for muse models)
const FALLBACK_KEY = process.env.ZEN_KEY;
const ZEN = process.env.ZEN_URL || 'https://opencode.ai/zen/v1';
const SPOOF = {
  'User-Agent': 'opencode/1.18.31 ai-sdk/provider-utils/4.0.40 runtime/bun/1.3.14',
  'x-opencode-client': 'cli',
  'x-opencode-project': 'global',
  'x-opencode-request': 'msg_0b20bce72001HhNaOVex180aKz',
  'x-opencode-session': 'ses_f4df4cb3bffetj5bTDp2vZHLRH',
};
const TOOLS = [
  { type: 'function', name: 'bash', description: 'x', parameters: { type: 'object', properties: {}, required: [] }, strict: false },
  { type: 'function', name: 'read', description: 'x', parameters: { type: 'object', properties: {}, required: [] }, strict: false },
];

const RESPONSES_ONLY = /^(muse-|gpt-|grok-|jev-)/;

import { createServer } from "node:http";
import fs from "node:fs";

createServer(async (req, res) => {
  if (req.method === 'POST' && req.url.includes('/messages')) {
    let body = '';
    for await (const c of req) body += c;
    let a; try { a = JSON.parse(body); } catch { res.writeHead(400).end('{"error":"bad json"}'); return; }
    const KEY = (req.headers['authorization'] || '').replace(/^Bearer\s+/i, '') || FALLBACK_KEY;
    const sysText = typeof a.system === 'string' ? a.system : Array.isArray(a.system) ? a.system.map(b => b.text || '').join('\n') : '';
    const chatMsgs = [];
    if (sysText) chatMsgs.push({ role: 'system', content: sysText });
    for (const m of (a.messages || [])) {
      const text = typeof m.content === 'string' ? m.content : (m.content || []).map(b => b.text || '').join('');
      chatMsgs.push({ role: m.role, content: text });
    }
    // anthropic tools -> openai function tools (pass through if already openai-shaped, e.g. injected by CPA), plus gate dummies
    const oaiTools = (a.tools || []).map(t => (t && (t.function?.name || (t.type === 'function' && t.name)))
      ? { type: 'function', function: { name: t.function?.name ?? t.name, description: t.function?.description ?? t.description ?? 'x', parameters: t.function?.parameters ?? t.parameters ?? { type: 'object', properties: {} } } }
      : { type: 'function', function: { name: t.name, description: t.description || 'x', parameters: t.input_schema || { type: 'object', properties: {} } } });
    const hasTool = (n) => oaiTools.some(t => (t.name ?? t.function?.name) === n);
    if (!hasTool('bash')) oaiTools.unshift({ type: 'function', function: { name: 'bash', description: 'x', parameters: { type: 'object', properties: {}, required: [] } } });
    if (!hasTool('read')) oaiTools.push({ type: 'function', function: { name: 'read', description: 'x', parameters: { type: 'object', properties: {}, required: [] } } });
    const wantStream = a.stream === true;
    let fullText = '';
    const toolCalls = {}; // id -> {name, args}
    const feedResponses = async (url, payload) => {
      const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${KEY}`, Accept: 'text/event-stream', ...SPOOF }, body: JSON.stringify(payload) });
      if (!r.ok) return { status: r.status, err: await r.text() };
      const reader = r.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n\n')) >= 0) {
          const chunk = buf.slice(0, i); buf = buf.slice(i + 2);
          const ev = chunk.match(/^event: (.*)$/m)?.[1];
          const dl = chunk.match(/^data: (.*)$/m)?.[1];
          if (!dl || dl === '[DONE]') continue;
          let d; try { d = JSON.parse(dl); } catch { continue; }
          if (url.endsWith('/chat/completions')) {
            const delta = d.choices?.[0]?.delta;
            if (delta?.content) { fullText += delta.content; if (wantStream) sseText(delta.content); }
            for (const tc of (delta?.tool_calls || [])) {
              const id = tc.id || `call_${tc.index ?? 0}`;
              toolCalls[id] = toolCalls[id] || { name: tc.function?.name || '', args: '' };
              if (tc.function?.name) toolCalls[id].name = tc.function.name;
              if (tc.function?.arguments) toolCalls[id].args += tc.function.arguments;
            }
          } else {
            if (ev === 'response.output_text.delta' && d.delta) { fullText += d.delta; if (wantStream) sseText(d.delta); }
            const item = d.item || d.output?.find?.(o => o.type === 'function_call');
            if (d.type === 'response.output_item.added' && item?.type === 'function_call') {
              toolCalls[item.call_id || item.id] = { name: item.name || '', args: '' };
            }
            if ((ev === 'response.function_call_arguments.delta' || d.type === 'response.function_call_arguments.delta') && d.delta) {
              const ids = Object.keys(toolCalls);
              if (ids.length) toolCalls[ids[ids.length - 1]].args += d.delta;
            }
            if (d.type === 'response.completed' || ev === 'response.completed') {
              for (const o of (d.response?.output || d.output || [])) {
                if (o.type === 'function_call') toolCalls[o.call_id || o.id] = { name: o.name, args: o.arguments || '' };
                if (o.type === 'message') for (const p of (o.content || [])) { if ((p.type === 'output_text') && p.text && !fullText) fullText = p.text; }
              }
            }
          }
        }
      }
      return { status: 200 };
    };
    const sseText = (t) => res.write(`event: content_block_delta\ndata: ${JSON.stringify({ type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: t } })}\n\n`);
    const msgId = 'msg_bridge_' + Date.now().toString(36);
    if (wantStream) {
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write(`event: message_start\ndata: ${JSON.stringify({ type: 'message_start', message: { id: msgId, type: 'message', role: 'assistant', model: a.model, content: [], stop_reason: null, usage: { input_tokens: 0, output_tokens: 0 } } })}\n\n`);
      res.write(`event: content_block_start\ndata: ${JSON.stringify({ type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } })}\n\n`);
    }
    let out;
    if (!RESPONSES_ONLY.test(a.model)) {
      out = await feedResponses(`${ZEN}/chat/completions`, { model: a.model, messages: chatMsgs, stream: true, tools: oaiTools, max_tokens: a.max_tokens });
    } else {
      out = await feedResponses(`${ZEN}/responses`, { model: a.model, input: chatMsgs.map(m => ({ role: m.role, content: [{ type: m.role === 'assistant' ? 'output_text' : 'input_text', text: m.content }] })), stream: true, tools: oaiTools.map(t => ({ type: 'function', name: t.function?.name ?? t.name, description: t.function?.description ?? 'x', parameters: t.function?.parameters ?? { type: 'object', properties: {} }, strict: false })) });
    }
    if (out.status !== 200) { if (wantStream) { res.end(); } else { res.writeHead(out.status).end(out.err); } return; }
    const blocks = [];
    if (fullText) blocks.push({ type: 'text', text: fullText });
    let ti = blocks.length;
    for (const [id, tc] of Object.entries(toolCalls)) {
      if (!tc.name) continue;
      let args = {};
      try { args = JSON.parse(tc.args || '{}'); } catch { args = {}; }
      blocks.push({ type: 'tool_use', id, name: tc.name, input: args });
      if (wantStream) res.write(`event: content_block_start\ndata: ${JSON.stringify({ type: 'content_block_start', index: ti, content_block: { type: 'tool_use', id, name: tc.name, input: {} } })}\n\n`);
      if (wantStream && tc.args) res.write(`event: content_block_delta\ndata: ${JSON.stringify({ type: 'content_block_delta', index: ti, delta: { type: 'input_json_delta', partial_json: tc.args } })}\n\n`);
      ti++;
    }
    if (wantStream) {
      res.write(`event: content_block_stop\ndata: ${JSON.stringify({ type: 'content_block_stop', index: 0 })}\n\n`);
      res.write(`event: message_delta\ndata: ${JSON.stringify({ type: 'message_delta', delta: { stop_reason: blocks.some(b => b.type === 'tool_use') ? 'tool_use' : 'end_turn' }, usage: { output_tokens: 0 } })}\n\n`);
      res.write(`event: message_stop\ndata: ${JSON.stringify({ type: 'message_stop' })}\n\n`);
      res.end(); return;
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ id: msgId, type: 'message', role: 'assistant', model: a.model, content: blocks, stop_reason: blocks.some(b => b.type === 'tool_use') ? 'tool_use' : 'end_turn', usage: { input_tokens: 0, output_tokens: 0 } }));
    return;
  }
  if (req.method !== 'POST' || !req.url.includes('/chat/completions')) {
    res.writeHead(404).end('{}'); return;
  }
  let body = '';
  for await (const c of req) body += c;
  const j = JSON.parse(body);
  const KEY = (req.headers['authorization'] || '').replace(/^Bearer\s+/i, '') || FALLBACK_KEY;
  // ensure free-tier gate: tools must contain a "bash" tool and >=2 tools
  if (!Array.isArray(j.tools)) j.tools = [];
  const hasTool = (n) => j.tools.some(t => (t.name ?? t.function?.name) === n);
  if (!hasTool('bash')) j.tools.unshift({ type: 'function', function: { name: 'bash', description: 'x', parameters: { type: 'object', properties: {}, required: [] } } });
  if (!hasTool('read')) j.tools.push({ type: 'function', function: { name: 'read', description: 'x', parameters: { type: 'object', properties: {}, required: [] } } });
  if (!RESPONSES_ONLY.test(j.model)) {
    // passthrough to Zen chat/completions with spoof headers
    const r = await fetch(`${ZEN}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${KEY}`, Accept: 'text/event-stream', ...SPOOF },
      body: JSON.stringify({ ...j, stream: true }),
    });
    res.writeHead(r.status, { 'Content-Type': r.headers.get('content-type') || 'text/event-stream' });
    const reader = r.body.getReader();
    while (true) { const { done, value } = await reader.read(); if (done) break; res.write(value); }
    res.end(); return;
  }
  // convert chat -> responses
  const input = j.messages.map(m => ({ role: m.role, content: [{ type: m.role === 'assistant' ? 'output_text' : 'input_text', text: typeof m.content === 'string' ? m.content : m.content?.map(p => p.text).join('') }] }));
  const r = await fetch(`${ZEN}/responses`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${KEY}`, Accept: 'text/event-stream', ...SPOOF },
    body: JSON.stringify({ model: j.model, input, stream: true, tools: j.tools?.map(t => ({ type: 'function', name: t.function?.name ?? t.name, description: t.function?.description ?? t.description ?? 'x', parameters: t.function?.parameters ?? t.parameters ?? { type: 'object', properties: {} }, strict: false })) ?? TOOLS }),
  });
  if (!r.ok) { res.writeHead(r.status).end(await r.text()); return; }
  res.writeHead(200, { 'Content-Type': 'text/event-stream' });
  const id = 'bridge-' + Date.now();
  const reader = r.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  const send = (obj) => res.write(`data: ${JSON.stringify(obj)}\n\n`);
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let i;
    while ((i = buf.indexOf('\n\n')) >= 0) {
      const chunk = buf.slice(0, i); buf = buf.slice(i + 2);
      const ev = chunk.match(/^event: (.*)$/m)?.[1];
      const dataLine = chunk.match(/^data: (.*)$/m)?.[1];
      if (!dataLine) continue;
      let d; try { d = JSON.parse(dataLine); } catch { continue; }
      if (ev === 'response.output_text.delta' && d.delta) {
        send({ id, object: 'chat.completion.chunk', created: Math.floor(Date.now()/1000), model: j.model, choices: [{ index: 0, delta: { content: d.delta }, finish_reason: null }] });
      } else if (ev === 'response.completed' || (d.type === 'response.completed')) {
        send({ id, object: 'chat.completion.chunk', created: Math.floor(Date.now()/1000), model: j.model, choices: [{ index: 0, delta: {}, finish_reason: 'stop' }] });
      }
    }
  }
  res.write('data: [DONE]\n\n');
  res.end();
}).listen(9912, '127.0.0.1', () => console.log('zen-bridge on :9912'));
