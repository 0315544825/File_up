#!/bin/bash
# keep-alive loop: CPA(:8081) + zen-bridge(:9912) + fileserver(:9913) + caddy(:8080)
while true; do
  pgrep -f 'zen-bridge.mjs' >/dev/null || (ZEN_KEY="sk-giy6IGkFIYymmxoxm0kk6vUblVBfslbjrEIqBt2vsUhjNdJwrZJSEHCvVQhWhmAd" setsid -f node /app/cliproxyapi/zen-bridge.mjs >> /var/log/zenbridge.log 2>&1)
  code=$(curl -sS -o /dev/null -m 5 -w "%{http_code}" http://localhost:8081/v1/models)
  if ! pgrep -f 'cli-proxy-api -config' >/dev/null || [ "$code" = "000" ] || [ -z "$code" ]; then
    echo "[$(date -Is)] restarting cli-proxy-api (http=$code)..." >> /var/log/cpa-keepalive.log
    pkill -f 'cli-proxy-api -config'
    sleep 2
    setsid -f /app/cliproxyapi/cli-proxy-api -config /app/cliproxyapi/config.yaml >> /var/log/cliproxyapi.log 2>&1
  fi
  pgrep -f 'filebrowser.*9913' >/dev/null || (cd /app/filebrowser && setsid -f ./filebrowser -r / -a 127.0.0.1 -p 9913 -b /files -d /app/filebrowser/filebrowser.db >> /var/log/filebrowser.log 2>&1)
  pgrep -f 'caddy run --config /app/cliproxyapi/Caddyfile' >/dev/null || (setsid -f caddy run --config /app/cliproxyapi/Caddyfile --adapter caddyfile >> /var/log/caddy.log 2>&1)
  sleep 30
done
